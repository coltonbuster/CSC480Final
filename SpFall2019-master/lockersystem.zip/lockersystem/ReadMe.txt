database file in DB folder 


database name :  lockersystem



locker system login 

Admin:
Admin id = 0101
password = 12345678

student:
student id = 0496105
password = dodi1234

