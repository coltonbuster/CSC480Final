<?php
  session_start();
  // require 'session.php';
  include 'navbar.php';
  require 'model/db.php';
  require 'phpmailer/PHPMailerAutoload.php';

  // if user already login redirect them to index page
  if (isset($_SESSION['s_id'])) {
    header("Location: index.php");
  }

  $msg = $msgClass = '';

  // Check for submit
  if (filter_has_var(INPUT_POST, 'submit')){
    // Get form data
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $idc = substr($id, 1);

    $code = mt_rand(100000,999999);
    // $to = $email;
    // $subject = "Email verification";
    $mail_body = 'Your verificatio code is '.$code;
    // $headers = 'From:  info@lockersystem.com';

     $mail = new PHPMailer;
     $mail->IsSMTP();        //Sets Mailer to send message using SMTP
     $mail->SMTPDebug = SMTP::DEBUG_SERVER;
     $mail->Host = 'smtp.gmail.com';  //Sets the SMTP hosts of your Email hosting.
     $mail->Port = '587';        //Sets the default SMTP server port
     //Set the encryption mechanism to use - STARTTLS or SMTPS
     //$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
     $mail->SMTPAuth = true;       //Sets SMTP authentication. Utilizes the Username and Password variables
     $mail->Username = 'smulockers@gmail.com';     //Sets SMTP username
     $mail->Password = 'Ahmed2019';     //Sets SMTP password
     $mail->SMTPSecure = 'tls';       //Sets connection prefix. Options are "", "ssl" or "tls"
     $mail->From = 'smulockers@gmail.com';   //Sets the From email address for the message
     $mail->FromName = 'Locker System';     //Sets the From name of the message
     $mail->AddAddress($email, $username);  //Adds a "To" address   
     $mail->WordWrap = 70;       //Sets word wrapping on the body of the message to a given number of characters
     $mail->IsHTML(true);       //Sets message type to HTML    
     $mail->Subject = 'Email Verification';   //Sets the Subject of the message
     $mail->Body = $mail_body;       //An HTML or plain text message body

     $domain = explode('@', $email)[1];

    // Check required fields
    if (!empty($id) && !empty($username) && !empty($email) && !empty($password)){
      // pass
      // Check email
      if (filter_var($email, FILTER_VALIDATE_EMAIL) === false){
        // failed
        $msg = "Please use a valid email";
        $msgClass = "red";
      }else if($idc<400000 || $idc>650000){
       $msg = "Please enter valid student id (0400000 to 0650000)";
       $msgClass = "red";
      }else if($id[0]!="0"){
       $msg = "Student id should start with a 0 eg 0410000";
       $msgClass = "red";
      }else if($domain!="stmartin.edu"){
       $msg = "Please enter valid school email";
       $msgClass = "red";
      }else {
        // pass
        // Hashing the password
        $hashedPwd = password_hash($_POST['password'], PASSWORD_DEFAULT);
        // var_dump($hashedPwd);

        // Insert user into database
        $sql = "INSERT INTO `student` (`student_id`, `student_username`, `student_pwd`, `student_email`, `code`, `verified`)
        VALUES ('$id', '$username', '$hashedPwd', '$email', '$code', 'no')";

        if (mysqli_query($conn, $sql)){
          header("Location: emailverify.php");
          $_SESSION['reg_user']=$id;
          // mail($to,$subject,$message,$headers);
          $mail->Send();
        } else {
          $msg = "Register error: " . $sql . "<br>" . mysqli_error($conn);
          $msgClass = "red";
        }
      }
    } else {
      // failed
      $msg = "Please fill in all fields";
      $msgClass = "red";
    }
  }
?>

<!-- Register form -->
<div class="container">
  <div class="box">
    <div class="row">
      <div class="col s12 m12">
        <?php if($msg != ''): ?>
          <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
            <span class="white-text"><?php echo $msg; ?></span>
          </div>
        <?php endif ?>
        <div class="card">
          <div class="card-content">
            <span class="card-title center-align">User Registration Form</span>
            <div class="row">
              <form class="col s12" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" novalidate>
                <div class="row">
                  <div class="input-field">
                    <i class="material-icons prefix">credit_card</i>
                    <input type="text" id="id" name="id" value="<?php echo isset($_POST['id']) ? $id : ''; ?>">
                    <label for="id">Your User Id</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field">
                    <i class="material-icons prefix">face</i>
                    <input type="text" id="name" name="username" value="<?php echo isset($_POST['username']) ? $username : ''; ?>">
                    <label for="name">Your Username</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field">
                    <i class="material-icons prefix">email</i>
                    <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? $email : ''; ?>">
                    <label for="email">Your Email</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field">
                    <i class="material-icons prefix">lock</i>
                    <input type="password" id="password" name="password">
                    <label for="userid">Your password</label>
                  </div>
                </div>
                <div class="row">
                  <p class="center-align">
                    Already register? <a href="login.php">Login</a><br><br>
                    <button type="submit" class="waves-effect waves-light btn blue" name="submit">Register</button>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>