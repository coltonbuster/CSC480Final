-- phpMyAdmin SQL Dump
-- version 3.2.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2019 at 09:46 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lockersystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(15) NOT NULL,
  `admin_username` varchar(255) NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `admin_phone` int(30) NOT NULL,
  `admin_password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_email`, `admin_phone`, `admin_password`) VALUES
('0101', 'Ahmed', 'smulockers@gmail.com', 123456789, '$2y$10$9POuMtOoZL4y.fm7igF9suVloTZGqfMg3KS2XFtYn6ASeqyipNRbC');

-- --------------------------------------------------------

--
-- Table structure for table `locker`
--

CREATE TABLE `locker` (
  `locker_id` varchar(15) NOT NULL,
  `locker_status` varchar(15) NOT NULL,
  `locker_price` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locker`
--

INSERT INTO `locker` (`locker_id`, `locker_status`, `locker_price`) VALUES
('L001', 'Booked', 1),
('L002', 'Available', 1),
('L003', 'Available', 1),
('L004', 'Available', 1),
('L005', 'Available', 1),
('L006', 'Available', 1),
('L007', 'Available', 1),
('L008', 'Available', 1),
('L009', 'Available', 1),
('L010', 'Available', 1);

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `record_id` int(11) NOT NULL,
  `record_start` varchar(10) DEFAULT NULL,
  `record_end` varchar(10) DEFAULT NULL,
  `record_price` int(11) DEFAULT NULL,
  `record_item` varchar(255) DEFAULT NULL,
  `record_status` varchar(10) NOT NULL DEFAULT 'pending',
  `record_sub` varchar(10) NOT NULL DEFAULT 'expired',
  `record_approved_by` varchar(15) NOT NULL,
  `student_id` varchar(15) NOT NULL,
  `locker_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(15) NOT NULL,
  `student_username` varchar(100) NOT NULL,
  `student_pwd` char(70) NOT NULL,
  `student_email` varchar(30) NOT NULL,
  `code` int(11) NOT NULL,
  `verified` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_username`, `student_pwd`, `student_email`, `code`, `verified`) VALUES
('0496105', 'alharbi', '$2y$10$QoSoITcf6hSQpV3L.eLPteEZJsW2g2sBibo7Liy9E8jtovTX8szdW', 'ahmed.alharbi@stmartin.edu', 654286, 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `locker`
--
ALTER TABLE `locker`
  ADD PRIMARY KEY (`locker_id`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
